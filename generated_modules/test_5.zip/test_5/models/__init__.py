# -*- coding: utf-8 -*-
from . import test_5_property
